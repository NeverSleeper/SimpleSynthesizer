﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/


using System; //Math

namespace WaveLibrary
{

    /// <summary>
    /// This class represents an oscillator. It's possible to create different kind of wave forms if a given frequency, samplerate and amplitude is given into the function. 
    /// If you want to create a continous play it will be necessary to save the angle value in the oscillator functions and use the angle value as a new input for the next calculation.
    /// 
    /// Creation Date: 
    /// Update Date: 2018-06-04
    /// </summary>
    public static class Oscillator
    {
        static double TWOPI = 2 * Math.PI;

        /// <summary>
        /// Creates a sine wave with a given frequency.
        /// Source: The Audio Programming Book - Page: 263
        /// </summary>
        /// <param name="freq">Frequency</param>
        /// <param name="sampleRate">Samplerate</param>
        /// <param name="frames">Count of frames (frames =  samplerate / time)</param>
        /// <param name="maxAmp">Amplitude</param>
        /// <returns>An int array which contains a sine wave.</returns>
        public static int[] SinusWaveForm(double angle, double freq, int sampleRate, int frames, int maxAmp)
        {
            int[] output = new int[frames];

            double curphase = angle;
            double incr = freq * Math.PI / sampleRate;
            incr = incr * 2;

            for (int i = 0; i < frames; i++)
            {
                double sinPhase = Math.Sin(curphase);
                output[i] = (int)Math.Round(sinPhase * maxAmp);

                curphase = curphase + incr;

                if (curphase >= TWOPI)
                {
                    curphase -= TWOPI;
                }
            }
            return output;
        }


        /// <summary>
        /// Creates a square wave.
        /// Source: The Audio Programming Book - Page: 272
        /// </summary>
        /// <param name="freq">Frequency</param>
        /// <param name="sampleRate">Samplerate</param>
        /// <param name="frames">Count of frames (frames =  samplerate / time)</param>
        /// <param name="maxAmp">Amplitude</param>
        /// <returns>An int array which contains a square wave.</returns>
        public static int[] SquareWaveForm(double angle, double freq, int sampleRate, int frames, int maxAmp)
        {
            int[] output = new int[frames];

            double curphase = angle;
            double curFreq = 0;

            double incr = freq * Math.PI / sampleRate;
            incr = incr * 2;
            double twoPiOvSr = TWOPI / sampleRate;
            int value = 0;

            for (int i = 0; i < frames; i++)
            {
                if (curFreq != freq)
                {
                    curFreq = freq;
                    incr = twoPiOvSr * freq;
                }

                if (curphase <= Math.PI)
                {
                    value = maxAmp;
                }
                else
                {
                    value = maxAmp * -1;
                }

                curphase = curphase + incr;

                if (curphase >= TWOPI)
                {

                    curphase = curphase - TWOPI;
                }
                if (curphase < 0.0)
                {

                    curphase = curphase + TWOPI;
                }

                output[i] = value;
            }
            return output;
        }



        /// <summary>
        /// Creates a triangle wave.
        /// Source: The Audio Programming Book - Page: 273
        /// </summary>
        /// <param name="freq">Frequency</param>
        /// <param name="sampleRate">Samplerate</param>
        /// <param name="frames">Count of frames (frames =  samplerate / time)</param>
        /// <param name="maxAmp">Amplitude</param>
        /// <returns>An int array which contains a triangle wave.</returns>
        public static int[] TriangleWaveForm(double angle, double freq, int sampleRate, int frames, int maxAmp)
        {
            int[] output = new int[frames];

            double curphase = angle;
            double curFreq = 0;

            double incr = freq * Math.PI / sampleRate;
            incr = incr * 2;
            double twoPiOvSr = TWOPI / sampleRate;
            double value = 0;

            for (int i = 0; i < frames; i++)
            {
                if (curFreq != freq)
                {
                    curFreq = freq;
                    incr = twoPiOvSr * freq;
                }

                value = 2.0 * (curphase * (1 / TWOPI)) - 1;

                if (value < 0.0)
                {
                    value = -1 * value;
                }

                value = 2 * (value - 0.5);
                curphase = curphase + incr;
                

                if (curphase >= TWOPI)
                {
                    curphase = curphase - TWOPI;
                }
                if (curphase < 0.0)
                {
                    curphase = curphase + TWOPI;
                }

                value = value * maxAmp;
                output[i] = (int)value;
            }
            return output;
        }


        /// <summary>
        /// Creates an upward sawtooth wave.
        /// Source: The Audio Programming Book - Page: 272 - 273
        /// </summary>
        /// <param name="freq">Frequency</param>
        /// <param name="sampleRate">Samplerate</param>
        /// <param name="frames">Count of frames (frames =  samplerate / time)</param>
        /// <param name="maxAmp">Amplitude</param>
        /// <returns>An int array which contains a sine wave.</returns>
        public static int[] UpwardSawToothWaveForm(double angle, double freq, int sampleRate, int frames, int maxAmp)
        {
            int[] output = new int[frames];

            double curphase = angle;
            double curFreq = 0;

            double incr = freq * Math.PI / sampleRate;
            incr = incr * 2;
            double twoPiOvSr = TWOPI / sampleRate;
            double value = 0;

            for (int i = 0; i < frames; i++)
            {
                if (curFreq != freq)
                {
                    curFreq = freq;
                    incr = twoPiOvSr * freq;
                }

                value = (2.0 * (curphase * (1.0 / TWOPI))) - 1.0;
                curphase = curphase + incr;

                if (curphase >= TWOPI)
                {
                    curphase = curphase - TWOPI;
                }
                if (curphase < 0.0)
                {
                    curphase = curphase + TWOPI;
                }
                output[i] = (int)(value * maxAmp);
            }
            return output;
        }
    }
}
