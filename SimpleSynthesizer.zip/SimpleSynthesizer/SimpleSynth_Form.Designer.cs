﻿namespace WaveLibrary
{
    partial class SimpleSynth_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPlay = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.trackBarFrequency = new System.Windows.Forms.TrackBar();
            this.trackBarAmplitude = new System.Windows.Forms.TrackBar();
            this.tbAmplitudeVal = new System.Windows.Forms.TextBox();
            this.tbFreqVal = new System.Windows.Forms.TextBox();
            this.groupBoxFrequency = new System.Windows.Forms.GroupBox();
            this.groupBoxEnvelope = new System.Windows.Forms.GroupBox();
            this.rbWaveSaw = new System.Windows.Forms.RadioButton();
            this.rbWaveSquare = new System.Windows.Forms.RadioButton();
            this.rbWaveTriangle = new System.Windows.Forms.RadioButton();
            this.groupBoxWaveOutput = new System.Windows.Forms.GroupBox();
            this.rbWaveSine = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarFrequency)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmplitude)).BeginInit();
            this.groupBoxFrequency.SuspendLayout();
            this.groupBoxEnvelope.SuspendLayout();
            this.groupBoxWaveOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(15, 358);
            this.btnPlay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(410, 172);
            this.btnPlay.TabIndex = 16;
            this.btnPlay.Text = "Start Oscillator";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // radioButton3
            // 
            this.radioButton3.Location = new System.Drawing.Point(0, 0);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(104, 24);
            this.radioButton3.TabIndex = 0;
            // 
            // radioButton4
            // 
            this.radioButton4.Location = new System.Drawing.Point(0, 0);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(104, 24);
            this.radioButton4.TabIndex = 0;
            // 
            // radioButton5
            // 
            this.radioButton5.Location = new System.Drawing.Point(0, 0);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(104, 24);
            this.radioButton5.TabIndex = 0;
            // 
            // radioButton6
            // 
            this.radioButton6.Location = new System.Drawing.Point(0, 0);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(104, 24);
            this.radioButton6.TabIndex = 0;
            // 
            // trackBarFrequency
            // 
            this.trackBarFrequency.Location = new System.Drawing.Point(3, 32);
            this.trackBarFrequency.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.trackBarFrequency.Maximum = 1000;
            this.trackBarFrequency.Minimum = 1;
            this.trackBarFrequency.Name = "trackBarFrequency";
            this.trackBarFrequency.Size = new System.Drawing.Size(318, 69);
            this.trackBarFrequency.TabIndex = 49;
            this.trackBarFrequency.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarFrequency.Value = 440;
            this.trackBarFrequency.ValueChanged += new System.EventHandler(this.trackBarFrequency_ValueChanged);
            // 
            // trackBarAmplitude
            // 
            this.trackBarAmplitude.Location = new System.Drawing.Point(2, 45);
            this.trackBarAmplitude.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.trackBarAmplitude.Name = "trackBarAmplitude";
            this.trackBarAmplitude.Size = new System.Drawing.Size(324, 69);
            this.trackBarAmplitude.TabIndex = 60;
            this.trackBarAmplitude.Value = 5;
            this.trackBarAmplitude.ValueChanged += new System.EventHandler(this.trackBarAmplitude_ValueChanged);
            // 
            // tbAmplitudeVal
            // 
            this.tbAmplitudeVal.Location = new System.Drawing.Point(334, 43);
            this.tbAmplitudeVal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbAmplitudeVal.Name = "tbAmplitudeVal";
            this.tbAmplitudeVal.Size = new System.Drawing.Size(61, 26);
            this.tbAmplitudeVal.TabIndex = 62;
            this.tbAmplitudeVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbFreqVal
            // 
            this.tbFreqVal.Location = new System.Drawing.Point(330, 29);
            this.tbFreqVal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbFreqVal.Name = "tbFreqVal";
            this.tbFreqVal.Size = new System.Drawing.Size(61, 26);
            this.tbFreqVal.TabIndex = 50;
            this.tbFreqVal.Text = "440";
            this.tbFreqVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBoxFrequency
            // 
            this.groupBoxFrequency.Controls.Add(this.trackBarFrequency);
            this.groupBoxFrequency.Controls.Add(this.tbFreqVal);
            this.groupBoxFrequency.Location = new System.Drawing.Point(18, 254);
            this.groupBoxFrequency.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxFrequency.Name = "groupBoxFrequency";
            this.groupBoxFrequency.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxFrequency.Size = new System.Drawing.Size(408, 94);
            this.groupBoxFrequency.TabIndex = 69;
            this.groupBoxFrequency.TabStop = false;
            this.groupBoxFrequency.Text = "Frequency";
            // 
            // groupBoxEnvelope
            // 
            this.groupBoxEnvelope.Controls.Add(this.trackBarAmplitude);
            this.groupBoxEnvelope.Controls.Add(this.tbAmplitudeVal);
            this.groupBoxEnvelope.Location = new System.Drawing.Point(16, 117);
            this.groupBoxEnvelope.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxEnvelope.Name = "groupBoxEnvelope";
            this.groupBoxEnvelope.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxEnvelope.Size = new System.Drawing.Size(410, 120);
            this.groupBoxEnvelope.TabIndex = 64;
            this.groupBoxEnvelope.TabStop = false;
            this.groupBoxEnvelope.Text = "Volume";
            // 
            // rbWaveSaw
            // 
            this.rbWaveSaw.AutoSize = true;
            this.rbWaveSaw.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.rbWaveSaw.Location = new System.Drawing.Point(252, 29);
            this.rbWaveSaw.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbWaveSaw.Name = "rbWaveSaw";
            this.rbWaveSaw.Size = new System.Drawing.Size(69, 44);
            this.rbWaveSaw.TabIndex = 20;
            this.rbWaveSaw.Text = "Saw Up";
            this.rbWaveSaw.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbWaveSaw.UseVisualStyleBackColor = true;
            this.rbWaveSaw.CheckedChanged += new System.EventHandler(this.rbWaveSaw_CheckedChanged);
            // 
            // rbWaveSquare
            // 
            this.rbWaveSquare.AutoSize = true;
            this.rbWaveSquare.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.rbWaveSquare.Location = new System.Drawing.Point(86, 29);
            this.rbWaveSquare.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbWaveSquare.Name = "rbWaveSquare";
            this.rbWaveSquare.Size = new System.Drawing.Size(65, 44);
            this.rbWaveSquare.TabIndex = 18;
            this.rbWaveSquare.Text = "Square";
            this.rbWaveSquare.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbWaveSquare.UseVisualStyleBackColor = true;
            this.rbWaveSquare.CheckedChanged += new System.EventHandler(this.rbWaveSquare_CheckedChanged);
            // 
            // rbWaveTriangle
            // 
            this.rbWaveTriangle.AutoSize = true;
            this.rbWaveTriangle.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.rbWaveTriangle.Location = new System.Drawing.Point(170, 29);
            this.rbWaveTriangle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbWaveTriangle.Name = "rbWaveTriangle";
            this.rbWaveTriangle.Size = new System.Drawing.Size(69, 44);
            this.rbWaveTriangle.TabIndex = 19;
            this.rbWaveTriangle.Text = "Triangle";
            this.rbWaveTriangle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbWaveTriangle.UseVisualStyleBackColor = true;
            this.rbWaveTriangle.CheckedChanged += new System.EventHandler(this.rbWaveTriangle_CheckedChanged);
            // 
            // groupBoxWaveOutput
            // 
            this.groupBoxWaveOutput.Controls.Add(this.rbWaveSaw);
            this.groupBoxWaveOutput.Controls.Add(this.rbWaveSine);
            this.groupBoxWaveOutput.Controls.Add(this.rbWaveSquare);
            this.groupBoxWaveOutput.Controls.Add(this.rbWaveTriangle);
            this.groupBoxWaveOutput.Location = new System.Drawing.Point(14, 14);
            this.groupBoxWaveOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxWaveOutput.Name = "groupBoxWaveOutput";
            this.groupBoxWaveOutput.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBoxWaveOutput.Size = new System.Drawing.Size(412, 94);
            this.groupBoxWaveOutput.TabIndex = 68;
            this.groupBoxWaveOutput.TabStop = false;
            this.groupBoxWaveOutput.Text = "Waveform";
            // 
            // rbWaveSine
            // 
            this.rbWaveSine.AutoSize = true;
            this.rbWaveSine.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.rbWaveSine.Checked = true;
            this.rbWaveSine.Location = new System.Drawing.Point(21, 29);
            this.rbWaveSine.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbWaveSine.Name = "rbWaveSine";
            this.rbWaveSine.Size = new System.Drawing.Size(45, 44);
            this.rbWaveSine.TabIndex = 17;
            this.rbWaveSine.TabStop = true;
            this.rbWaveSine.Text = "Sine";
            this.rbWaveSine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbWaveSine.UseVisualStyleBackColor = true;
            this.rbWaveSine.CheckedChanged += new System.EventHandler(this.rbWaveSine_CheckedChanged);
            // 
            // SimpleSynth_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 545);
            this.Controls.Add(this.groupBoxFrequency);
            this.Controls.Add(this.groupBoxEnvelope);
            this.Controls.Add(this.groupBoxWaveOutput);
            this.Controls.Add(this.btnPlay);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SimpleSynth_Form";
            this.ShowInTaskbar = false;
            this.Text = "Simple Synthesizer";
            ((System.ComponentModel.ISupportInitialize)(this.trackBarFrequency)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmplitude)).EndInit();
            this.groupBoxFrequency.ResumeLayout(false);
            this.groupBoxFrequency.PerformLayout();
            this.groupBoxEnvelope.ResumeLayout(false);
            this.groupBoxEnvelope.PerformLayout();
            this.groupBoxWaveOutput.ResumeLayout(false);
            this.groupBoxWaveOutput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.TrackBar trackBarFrequency;
        private System.Windows.Forms.TrackBar trackBarAmplitude;
        private System.Windows.Forms.TextBox tbAmplitudeVal;
        private System.Windows.Forms.TextBox tbFreqVal;
        private System.Windows.Forms.GroupBox groupBoxFrequency;
        private System.Windows.Forms.GroupBox groupBoxEnvelope;
        private System.Windows.Forms.RadioButton rbWaveSaw;
        private System.Windows.Forms.RadioButton rbWaveSquare;
        private System.Windows.Forms.RadioButton rbWaveTriangle;
        private System.Windows.Forms.GroupBox groupBoxWaveOutput;
        private System.Windows.Forms.RadioButton rbWaveSine;
    }
}