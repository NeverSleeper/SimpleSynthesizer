﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/


namespace WaveLibrary
{
    /// <summary>
    /// This class holds different members for the wave file generation.
    /// </summary>
    abstract class Settings
    {

        #region Wave Type Declartion

        /// <summary>
        /// This enumeration holds different wave forms which are created differently.
        /// </summary>
        public enum WaveType
        {
            Sine,
            Square,
            Triangle,
            Saw
        };

        #endregion

        #region Class Members

        static public WaveType WAVETYPE = WaveType.Sine;
        static public int SAMPLERATE = 44100;
        static public int FRAMES = 441000; //2205;
        static public int BITSPERSAMPLE = 16;
        static public float AMPLITUDE = 0.5f;
        static public int FREQUENCY = 440;

        #endregion
    }
}
