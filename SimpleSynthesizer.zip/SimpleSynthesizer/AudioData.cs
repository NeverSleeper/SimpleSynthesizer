﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/

using System.IO; // File/MemoryStream
using System.Numerics; // BigInteger

using WaveLibrary;


namespace WaveLibrary
{
    /// <summary>
    /// This class represent an Audio Data structure so it could be easily converted into a PCM-Wave file.
    /// </summary>
    public class AudioData
    {
        #region ClassMembers

        public string savePath;
        int _bitsPerSample;
        int _sampleRate;
        int _numberOfChannels;
        int _blockAlign;
        int[][] _dataPerChannel;

        BigInteger _framesCount;
        double _time;
        MemoryStream _memoryStream;

        BigInteger _fileSize;
        BigInteger _dataChunkSize;

        int _fmtChunkSize;
        int _audioFormat;
        int _averageBytesPerSecond;
        long _dataStreamPosition;

        #endregion

        #region Constructor

        public AudioData() {
            _memoryStream = new MemoryStream();
            _numberOfChannels = 1;
            _dataPerChannel = new int[1][];
        }

        #endregion

        #region Methods

        /// <summary>
        /// Calculates and writes a Wave PCM-Header into the memory stream.
        /// </summary>
        /// <param name="sPath">Speicherpfad</param>
        public void CreateWaveHeader()
        {
                WaveCalculation.CalculateHeaderValues(this);
                WaveWriter.WriteHeaderInformation(this);
        }
        
        public void UpdateStream() {

            WaveWriter.WriteDataSamples(this);
//            WaveWriter.WriteDataSamples(this, this.DataPerChannel, this.StreamDataPosition);
            
            this.Stream.Position = 0;
        }

        /// <summary>
        /// Returns the samples of one channel.
        /// </summary>
        /// <param name="channel">Channel index</param>
        /// <returns>Array of sample values</returns>
        public int[] GetChannelData(int channel)
        {
            int[] channelData = _dataPerChannel[channel];

            return channelData;
        }

        /// <summary>
        /// Sets the samples of one channel.
        /// </summary>
        /// <param name="channel">channel index</param>
        /// <param name="channelData">sample values for the channel</param>
        public void SetChannelData(int channel, int[] channelData)
        {
            _dataPerChannel[channel] = channelData;
        }

        /// <summary>
        /// Saves the AudioData as a Wave-File.
        /// </summary>
        /// <param name="path">Save path for the wave file.</param>
        public void SaveAsFile(string path) {

            _memoryStream.Position = 0;
            FileStream fileStream = new FileStream(path, FileMode.Create);
            fileStream.Write(this._memoryStream.GetBuffer(), 0, this._memoryStream.GetBuffer().Length);

            fileStream.Close();
        }

        #endregion


        #region Properties



        public long StreamDataPosition {

            get {
                return _dataStreamPosition;
            }

            set {
                _dataStreamPosition = value;
            }
        }

        public BigInteger DataChunkSize {

            get {
                return _dataChunkSize;
            }
            set {
                _dataChunkSize = value;
            }
        }

        public int AverageBytesPerSecond{
            get{
                return _averageBytesPerSecond;
            }
            set{
                _averageBytesPerSecond = value;
            }
        }

        public int AudioFormat {

            get {
                return _audioFormat;
            }
            set {
                _audioFormat = value;
            }
        }

        public int FmtChunkSize {

            get {
                return _fmtChunkSize;
            }
            set {
                _fmtChunkSize = value;
            }
        }

        public BigInteger FileSize {

            get {
                return _fileSize;            
            }
            set {

                _fileSize = value;
            }
        }   


        public int BlockAlign {

            get
            {
                return _blockAlign;
            }
            set {

                _blockAlign = value;
            }
        }
        


        public int BitsPerSample {

            get {
                return _bitsPerSample;            
            }
            set {
                _bitsPerSample = value;
            }
        
        }

        public Stream Stream {

            get {
                return _memoryStream;
            }
        }


        public int SampleRate {

            get {
                return _sampleRate;
            }

            set {
                _sampleRate = value;
            }
        }


        public BigInteger NumberOfFrames{
    
            get{
                return _framesCount;
            }
            set {
                _framesCount = value;
            }
        }

        public int NumberOfChannels {

            get {
                return _numberOfChannels;
            }
            set {
                if(value > 0){
                    _numberOfChannels = value;
                    _dataPerChannel = new int[value][];
                }
            }
        }


        public double Time {

            get {
                return _time;
            }
            set {
                _time = value;
            }
        }

        public int[][] DataPerChannel {

            get {
                return _dataPerChannel;
            }
            set {
                _dataPerChannel = value;
            }
        }

        #endregion
    }
}
