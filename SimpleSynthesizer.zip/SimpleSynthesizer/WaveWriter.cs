﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/


using System; // BitConverter
using System.Text; // ASCII-Encoding
using System.IO; // File/Memorystream
using System.Numerics; // Biginteger

namespace WaveLibrary
{
    /// <summary>
    /// This class holds methods to write a full PCM wave file. It's optimized for 16 Bit and mono audio output.
    /// </summary>
    public static class WaveWriter
    {
        #region WaveHeaderInformation


        /// <summary>
        /// Writes a file header for a Wave file.
        /// This method is optimized for a PCM-Wave with: 16 Bit and one channel (mono).
        /// </summary>
        /// <param name="ad">AudioData-Object which should be manipulated.</param>
        public static void WriteHeaderInformation(AudioData ad)
        {
            StoreHeaderInformation(ad, "RIFF");
            StoreHeaderInformation(ad, "fmt ");
            StoreHeaderInformation(ad, "data");

//            ad.StreamDataPosition = ad.Stream.Position;            
        }

        /// <summary>
        /// Creates a full wave PCM header. It contains the following chunks:  "RIFF", "fmt " and "data". 
        /// </summary>
        /// <param name="ad">The AudioData object which should be manipulated</param>
        /// <param name="chunkID">The current chunk to write</param>
        private static void StoreHeaderInformation(AudioData ad, string chunkID)
        {
            System.Text.ASCIIEncoding decoder = new ASCIIEncoding();

            // den Namen in Bytes konvertieren und schreiben
            ad.Stream.Write(decoder.GetBytes(chunkID), 0, 4);

            switch (chunkID)
            {
                case "RIFF":
                    StoreRiffHeader(ad);
                    ad.Stream.Write(decoder.GetBytes("WAVE"), 0, 4);
                    break;

                case "fmt ":
                    StoreFmtHeader(ad);
                    break;

                case "data":
                    StoreDataHeader(ad);
                    break;
            }
        }

        /*
        /// <summary>
        /// Writes the "Riff" header for a wave file.
        /// If the file size is smaller than 4 bytes than trailling zeros will be appended.
        /// </summary>
        /// <param name="ad">AudioData-Object to override it stream</param>
        private static void StoreRiffHeader(AudioData ad)
        {
            // im RIFF Chunk, FileSize als Größe und das Audioformat schreiben                
            byte[] fileSize = ad.GetFileSize().ToByteArray();

            if (fileSize.Length < 4)
            {
                byte[] exportedFileSize = new byte[4];
                exportedFileSize.CopyTo(exportedFileSize, 0);
                fileSize = exportedFileSize;
            }
            ad.Stream.Write(fileSize, 0, 4);
        }

        */

        private static void StoreRiffHeader(AudioData ad)
        {
            // im RIFF Chunk, FileSize als Größe und das Audioformat schreiben                
            byte[] fileSize = ad.FileSize.ToByteArray();

            if (fileSize.Length < 4)
            {
                byte[] exportedFileSize = new byte[4];

                for (int i = 0; i < fileSize.Length; i++)
                {

                    exportedFileSize[i] = fileSize[i];
                }

                fileSize = exportedFileSize;
            }

            ad.Stream.Write(fileSize, 0, 4);
        }



        /// <summary>
        /// Writes the "fmt " header chunk for a PCM wave file.
        /// </summary>
        /// <param name="ad">The AudioData-Object where the stream will be overwritten.</param>
        private static void StoreFmtHeader(AudioData ad)
        {
            ad.Stream.Write(BitConverter.GetBytes(16), 0, 4);
            ad.Stream.Write(BitConverter.GetBytes(ad.AudioFormat), 0, 2);
            ad.Stream.Write(BitConverter.GetBytes(ad.NumberOfChannels), 0, 2);
            ad.Stream.Write(BitConverter.GetBytes(ad.SampleRate), 0, 4);
            ad.Stream.Write(BitConverter.GetBytes(ad.AverageBytesPerSecond), 0, 4);
            ad.Stream.Write(BitConverter.GetBytes(ad.BlockAlign), 0, 2);
            ad.Stream.Write(BitConverter.GetBytes(ad.BitsPerSample), 0, 2);
        }


        /// <summary>
        /// Writes the expected data chunk size of the wave file. 
        /// If the size is smaller then 4 the byte array will be appended with trailing zeros. 
        /// </summary>
        /// <param name="ad">The AudioData-Object where the stream will be overwritten.</param>
        private static void StoreDataHeader(AudioData ad)
        {
            // beim data Chunk die Größe des Datenblocks als Größenangabe schreiben
            byte[] expectedDataChunkSize = ad.DataChunkSize.ToByteArray();

            if (expectedDataChunkSize.Length < 4)
            {
                byte[] biggerDataChunkSize = new byte[4];
                expectedDataChunkSize.CopyTo(biggerDataChunkSize, 0);
                expectedDataChunkSize = biggerDataChunkSize;
            }
            ad.Stream.Write(expectedDataChunkSize, 0, 4);
        }
        
        #endregion

        #region AppendingData

        /// <summary>
        /// Appends and writes data samples after the wave header file into the stream of an AudioData-Object. 
        /// </summary>
        /// <param name="ad">AudioData-Object where the stream has to be manipulated</param>
        public static void WriteDataSamples(AudioData ad)
        {
     //       ad.Stream.Position = ad.StreamDataPosition; 
                
            for (int f = 0; f < ad.DataPerChannel[0].Length; f++)
            {
                 int value = ad.DataPerChannel[0][f];
                 byte[] backValue = WaveCalculation.ConvertByteToInt32(value, ad.BitsPerSample, ad.DataPerChannel.Length);
                 ad.Stream.Write(backValue, 0, backValue.Length);
            }//Frames
        }



        public static void WriteDataSamples(AudioData ad, int[][] dataSamples, long streamIndex)
        {
//            ad.Stream.Position = streamIndex;

            for (int f = 0; f < dataSamples[0].Length; f++)
            {
                for (int c = 0; c < dataSamples.Length; c++)
                {
                    int value = (int)dataSamples[c][f];
                    byte[] backValue = WaveCalculation.ConvertByteToInt32(value, ad.BitsPerSample, dataSamples.Length);
                    ad.Stream.Write(backValue, 0, backValue.Length);
                }//Frames
            }// Kanäle
        }


        #endregion
    }
}