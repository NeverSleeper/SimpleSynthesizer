﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/

using System;
using System.Numerics;
using System.IO;

namespace WaveLibrary
{

    /// <summary>
    /// This class calculates the values for the wave header and contains conversion methods for int to an byte array.
    /// </summary>
    public static class WaveCalculation
    {

        #region WaveHeaderCalculations

        /// <summary>
        /// Calculates the size of one frame in byte  which could contain many channels.
        /// </summary>
        /// <param name="bits">Bitdepth</param>
        /// <param name="nChannels">Number of channels</param>
        /// <returns>The bytesize of one frame</returns>
        private static  int CalculateBlockAlign(int bits, int nChannels)
        {
            int blockAlign = 0;
            blockAlign = (bits / 8) * nChannels;

            return blockAlign;
        }

        /// <summary>
        /// Calculates the file size for the "data"-chunk.
        /// </summary>
        /// <param name="samplingRate">Samplingrate</param>
        /// <param name="time">Time in seconds</param>
        /// <param name="nChannels">Number of channels</param>
        /// <param name="blockAlign">The size of one frame in bytes</param>
        /// <returns>The calculated sie for the data-chunk in byte.</returns>
        private static int CalculateDataChunkSize(int samplingRate, double time, int nChannels, int blockAlign)
        {
            int tempFrames = (int)Math.Round(samplingRate * time);
            int dataChunkSize = 0;

            dataChunkSize = tempFrames * nChannels * (blockAlign / nChannels);

            return dataChunkSize;
        }

        /// <summary>
        /// Calculates the "Average Bytes Per Second".
        /// These are the bytes needed per sample in a single channel.   
        /// </summary>
        /// <param name="bits">Bitrate</param>
        /// <param name="sampleRate">SamplingRate</param>
        /// <param name="nChannels">Number of channels</param>
        /// <returns>Calculated AverageBytesPerSecond value.</returns>
        private static int CalculateAverageBytesPerSecond(int bits, int sampleRate, int nChannels)
        {
            int averageBytesPerSecond = sampleRate * (bits / 8) * nChannels;

            return averageBytesPerSecond;
        }

        /// <summary>
        /// Calculates the file size for the whole wave file in bytes.
        /// With size 
        /// Kalkuliert die Dateigröße für die zu exportierende Wave-Datei in Bytes. 
        /// The file size here refers to the pure frames and not the header information.
        /// </summary>
        /// <param name="bits">Exported bitrate</param>
        /// <param name="nChannels"Number of channels</param>
        /// <param name="frames">Number of frames</param>
        /// <returns>Calculated wave file size</returns>
        private static BigInteger CalculateFileSize(int bits, int nChannels, BigInteger frames)
        {
            BigInteger iFileSize = 0;
            iFileSize = (bits / 8) * frames * nChannels;

            return iFileSize;
        }

        /// <summary>
        /// Calculates the time of the wave file.
        /// </summary>
        /// <param name="frames">Number of frames inside the wave file.</param>
        /// <param name="sampleRate">The samplingrate</param>
        /// <returns>Time of the wave file</returns>
        private static double CalculateTime(BigInteger frames, int sampleRate)
        {
            double time = (double)frames / (double)sampleRate;

            return time;
        }


        /// <summary>
        /// Calculates the number of frames in one wave file.
        /// The size of the "data"-chunk will be divided through the  Bitrate and  number of channels and be multiplied by 8.
        /// </summary>
        /// <param name="channels">Number of channels</param>
        /// <param name="bitsPerSample">Bits per Sample</param>
        /// <param name="dataChunkSize">size of the data chunk</param>
        /// <returns>Number of frames</returns>
        private static BigInteger CalculateFrames(int channels, int bitsPerSample, BigInteger dataChunkSize)
        {
            BigInteger frames = 0;

            frames = 8 * dataChunkSize / bitsPerSample / channels;

            return frames;
        }


        

        ///<summary>
        /// Calculates the file size, audio format, block-align, datachunksize, avagere bytes per second and number of frames for the wave file.
        /// </summary> 
        ///<param name="ad">The AudioData object witch should be manipulated.</param>
        public static void CalculateHeaderValues(AudioData ad)
        {            
            ad.AudioFormat = 1;
            ad.BlockAlign = CalculateBlockAlign(ad.BitsPerSample, ad.NumberOfChannels);
            ad.DataChunkSize = CalculateDataChunkSize(ad.SampleRate, ad.Time, ad.NumberOfChannels, ad.BlockAlign);
            ad.AverageBytesPerSecond = CalculateAverageBytesPerSecond(ad.BitsPerSample, ad.SampleRate, ad.NumberOfChannels);
            ad.NumberOfFrames = CalculateFrames(ad.NumberOfChannels, ad.BitsPerSample, ad.DataChunkSize);

            BigInteger expDataRate = CalculateFileSize(ad.BitsPerSample, ad.NumberOfChannels, ad.NumberOfFrames );
            ad.FileSize = expDataRate + 36;
        }

        #endregion

        #region Conversions

        /// <summary>
        /// Konvertiert einen int Wert in Byte um.
        /// </summary>
        /// <param name="value">Der aktuell umzuwandelnde Wert in Byte</param>
        /// <param name="bitDeph">Die zu exportierende Bittiefe</param>
        /// <returns>Den umgewandelten Wert in Byte</returns>
        public static byte[] ConvertByteToInt32(int value, int bitDeph, int numbChannels)
        {
            // je nachdem, wie viele Bytes für einen Wert genutzt werden,
            // die Amplitude als Int16 oder Int32 interpretieren
            byte[] b32 = BitConverter.GetBytes(value);
            byte[] valueInBytes = new byte[1];
                        
            valueInBytes = BitConverter.GetBytes(value);
            byte[] tempN = new byte[2];

            for (int b = 0; b < tempN.Length; b++)
            {
                tempN[b] = valueInBytes[b];
            }
            valueInBytes = tempN;

            return valueInBytes;
        }


        private static int GetDecimalPlaceCount(decimal value)
        {
            // Alle Bits außer Exponent auf 0 setzen und nach rechts schieben um den Wert zu erhalten.
            return (Decimal.GetBits(value)[3] & 0x0ff0000) >> 0x10;
        }      

        #endregion
    }
}
