﻿/*******************************************************
 * Copyright (C) 2018 <André Vallentin> <a.vallentin@gmx.de>
 * 
 * This file is part of the "Simple Synthesizer"-project
 * 
 * Simple Synthesizer can be copied and/or distributed without the express
 * permission of André Vallentin.
 *******************************************************/

using System.IO;
using System.Media;

/// <summary>
///  This class represents a MediaPlayer which is used to play a Wave-File from a memory stream.
///  Source:  * https://stackoverflow.com/questions/6340967/play-wav-mp3-from-memory, from 2018-06-01
/// </summary>
public class MediaPlayer
{

    #region Class Members

    SoundPlayer _soundPlayer;
    Stream _stream;
    
    #endregion

    #region Constructors
    public MediaPlayer(Stream stream)
    {        
        _soundPlayer = new System.Media.SoundPlayer(stream);
    }

    public MediaPlayer() {
        _soundPlayer = new System.Media.SoundPlayer();
    }
    #endregion

    #region Methods
    public void SetStream(Stream stream) {

        _stream = stream;
    }

    public void Play()
    {
        _soundPlayer.Stream.Position = 0;
        _soundPlayer.PlayLooping();
    }

    public void Stop() {
        _soundPlayer.Stop();
    }

    #endregion
}